import java.util.Scanner;

public class ineuron3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter an integer: ");
        
        try {
            int number = scanner.nextInt();
            
            if (number < 0) {
                throw new Exception("Negative number not allowed!");
            }
            
            System.out.println("You entered: " + number);
        } catch (Exception e) {
            System.out.println("Exception caught: " + e.getMessage());
        }
        
        scanner.close();
    }
}