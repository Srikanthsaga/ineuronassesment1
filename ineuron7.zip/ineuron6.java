
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

class Employee {
    private String name;
    private int age;
    private double salary;

    public Employee(String name, int age, double salary) {
        this.name = name;
        this.age = age;
        this.salary = salary;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public double getSalary() {
        return salary;
    }

    @Override
    public String toString() {
        return "Employee [name=" + name + ", age=" + age + ", salary=" + salary + "]";
    }
}

public class ineuron6 {
    public static void main(String[] args) {
        // Create a large dataset of employees
        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee("John", 35, 5000));
        employees.add(new Employee("Alice", 28, 4500));
        employees.add(new Employee("Bob", 40, 6000));
        employees.add(new Employee("Emily", 32, 5500));
        // ... Add more employees

        // Filtering employees based on a condition
        List<Object> filteredEmployees = employees.stream()
                .filter(e -> e.getAge() > 30 && e.getSalary() > 5000)
                .collect(Collectors.toList());
        System.out.println("Filtered employees:");
        filteredEmployees.forEach(System.out::println);

        // Sorting employees based on a property
        List<Employee> sortedEmployees = employees.stream()
                .sorted((e1, e2) -> Double.compare(e2.getSalary(), e1.getSalary()))
                .collect(Collectors.toList());
        System.out.println("\nSorted employees (by salary in descending order):");
        sortedEmployees.forEach(System.out::println);
    }
}
