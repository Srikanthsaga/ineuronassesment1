
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class ineuron10 {
    public static void main(String[] args) {
        List<Integer> numbers = new ArrayList<>();

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of integers: ");
        int count = scanner.nextInt();

        System.out.println("Enter the integers:");

        for (int i = 0; i < count; i++) {
            int number = scanner.nextInt();
            numbers.add(number);
        }

        if (numbers.size() < 2) {
            System.out.println("Insufficient numbers entered.");
        } else {
            int secondSmallest = findSecondSmallest(numbers);
            int secondLargest = findSecondLargest(numbers);

            System.out.println("Second Smallest: " + secondSmallest);
            System.out.println("Second Largest: " + secondLargest);
        }

        scanner.close();
    }

    public static int findSecondSmallest(List<Integer> numbers) {
        List<Integer> sortedNumbers = new ArrayList<>(numbers);
        Collections.sort(sortedNumbers);

        return sortedNumbers.get(1);
    }

    public static int findSecondLargest(List<Integer> numbers) {
        List<Integer> sortedNumbers = new ArrayList<>(numbers);
        Collections.sort(sortedNumbers, Collections.reverseOrder());

        return sortedNumbers.get(1);
    }
}
