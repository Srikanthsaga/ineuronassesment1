
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

public class ineuron9 {
    private static final int MAX_CAPACITY = 10;
    private static final int MAX_NUMBERS = 100;
    private static final Random random = new Random();

    public static void main(String[] args) {
        Queue<Integer> queue = new LinkedList<>();

        Thread producerThread = new Thread(new Producer(queue));
        Thread consumerThread = new Thread(new Consumer(queue));

        producerThread.start();
        consumerThread.start();
    }

    static class Producer implements Runnable {
        private final Queue<Integer> queue;

        public Producer(Queue<Integer> queue) {
            this.queue = queue;
        }

        @Override
        public void run() {
            for (int i = 0; i < MAX_NUMBERS; i++) {
                synchronized (queue) {
                    while (queue.size() == MAX_CAPACITY) {
                        try {
                            queue.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }

                    int number = random.nextInt(100);
                    queue.add(number);
                    System.out.println("Produced: " + number);
                    queue.notifyAll();
                }
            }
        }
    }

    static class Consumer implements Runnable {
        private final Queue<Integer> queue;

        public Consumer(Queue<Integer> queue) {
            this.queue = queue;
        }

        @Override
        public void run() {
            int sum = 0;

            for (int i = 0; i < MAX_NUMBERS; i++) {
                synchronized (queue) {
                    while (queue.isEmpty()) {
                        try {
                            queue.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }

                    int number = queue.poll();
                    sum += number;
                    System.out.println("Consumed: " + number);
                    queue.notifyAll();
                }
            }

            System.out.println("Sum of numbers: " + sum);
        }
    }
}
