class Parent {
    public Parent() {
        System.out.println("Parent class constructor invoked.");
    }
}

class Child extends Parent {
    public Child() {
        super(); // Invoke parent class constructor
        System.out.println("Child class constructor invoked.");
    }
}

public class ineuron2 {
    public static void main(String[] args) {
        Child child = new Child();
    }
}

